/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author kb9agt
 */
public class RunApplet {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        MidiApplet here = new MidiApplet();
        here.run();
    }

}
